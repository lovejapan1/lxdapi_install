<?php
// 防止任何意外输出
ob_start();

require_once __DIR__ . '/../../../init.php';
require_once __DIR__ . '/../../../includes/gatewayfunctions.php';
require_once __DIR__ . '/../../../includes/invoicefunctions.php';

$gatewayModuleName = 'alipaywhmcs';
$gateway = getGatewayVariables($gatewayModuleName);

if (!$gateway["type"]) {
    http_response_code(400);
    echo "Module Not Activated";
    exit;
}

// 获取支付宝回调数据
$postData = $_POST;

try {
    // 获取订单ID并验证
    $invoiceId = checkCbInvoiceID($postData['out_trade_no'], $gateway['name']);
    $transactionId = $postData['trade_no'];
    $paymentSuccess = ($postData['trade_status'] === 'TRADE_SUCCESS');

    if ($paymentSuccess) {
        // ====================== 关键修改：强制使用发票原始金额（USD） ======================
        $invoice = localAPI('GetInvoice', ['invoiceid' => $invoiceId]);
        $originalAmount = (float)$invoice['total'];   // 0.1 USD（原始金额）

        // 添加支付记录（使用原始金额）
        addInvoicePayment(
            $invoiceId,
            $transactionId,
            $originalAmount,   // ← 这里强制使用 0.1 USD，而不是支付宝返回的 0.68 RMB
            0,                 // 手续费
            $gatewayModuleName
        );

        logTransaction($gateway['name'], $postData, 'Success - Original Amount: ' . $originalAmount . ' ' . $invoice['currencycode']);
    } else {
        logTransaction($gateway['name'], $postData, 'Failed');
    }

    // 给支付宝返回成功通知
    http_response_code(200);
    echo 'success';
} catch (Exception $e) {
    logTransaction($gateway['name'], $postData, 'Error: ' . $e->getMessage());
    http_response_code(500);
    echo 'error';
}
exit;
?>